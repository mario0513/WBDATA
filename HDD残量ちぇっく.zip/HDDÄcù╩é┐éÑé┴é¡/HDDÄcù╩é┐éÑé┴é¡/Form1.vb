﻿Imports Microsoft.VisualBasic.FileIO

Public Class Form1
    'Log保存先の選択
    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        'FolderBrowserDialogクラスのインスタンスを作成
        Dim fbd As New FolderBrowserDialog

        '上部に表示する説明テキストを指定する
        fbd.Description = "logファイルの保存先を指定してください。"
        'ルートフォルダを指定する
        'デフォルトでDesktop
        fbd.RootFolder = Environment.SpecialFolder.Desktop
        '最初に選択するフォルダを指定する
        'RootFolder以下にあるフォルダである必要がある
        fbd.SelectedPath = "C:\"
        'ユーザーが新しいフォルダを作成できるようにする
        'デフォルトでTrue
        fbd.ShowNewFolderButton = True

        'ダイアログを表示する
        If fbd.ShowDialog(Me) = DialogResult.OK Then
            '選択されたフォルダを表示する
            Console.WriteLine(fbd.SelectedPath)
        End If
        TextBox12.Text = fbd.SelectedPath

    End Sub

    '空き容量取得
    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Dim NITIJI As String
        Dim JIKAN As String
        Dim A1_KIDOU, A2_KIDOU, A3_KIDOU, A4_KIDOU As Double

        ''自分のPC
        Dim dv As String = "C:"
        Dim mo As New System.Management.ManagementObject("Win32_LogicalDisk=""" & dv & """")
        Dim totalSize As Int64 = Convert.ToInt64(mo.Properties("Size").Value.ToString)
        Dim AKISize As Int64 = Convert.ToInt64(mo.Properties("FreeSpace").Value.ToString)
        TextBox1.Text = Format((totalSize / (1024 * 1024 * 1024)), ".0GB")
        TextBox2.Text = Format((AKISize / (1024 * 1024 * 1024)), ".0GB")
        TextBox3.Text = Format((AKISize / totalSize), "0.0%")


        If CheckBox1.Checked = False Then
            GoTo A2
        End If

A1:

        A1_KIDOU = 1
        On Error GoTo A2
        'ネットワーク経由
        'A1　X線空き容量
        Dim FSO, A1
        FSO = CreateObject("Scripting.FileSystemObject")
        A1 = FSO.GetFolder(TextBox10.Text)
        Dim AKISize_A1 = A1.Drive.FreeSpace
        Dim totalSize_A1 = A1.Drive.TotalSize

        TextBox4.Text = Format((totalSize_A1 / (1024 * 1024 * 1024)), ".0GB")
        TextBox5.Text = Format((AKISize_A1 / (1024 * 1024 * 1024)), ".0GB")
        TextBox6.Text = Format((AKISize_A1 / totalSize_A1), "00.0%")
        A1_KIDOU = 0


A2:
        If CheckBox2.Checked = False Then
            GoTo A3
        End If

        A2_KIDOU = 1
        On Error GoTo OWARI 'A3
        'ネットワーク経由
        'A2　X線空き容量
        Dim FSO2, A2
        FSO2 = CreateObject("Scripting.FileSystemObject")
        A2 = FSO2.GetFolder(TextBox11.Text)
        Dim totalSize_A2 = A2.Drive.TotalSize
        Dim AKISize_A2 = A2.Drive.FreeSpace
        TextBox7.Text = Format((totalSize_A2 / (1024 * 1024 * 1024)), ".0GB")
        TextBox8.Text = Format((AKISize_A2 / (1024 * 1024 * 1024)), ".0GB")
        TextBox9.Text = Format((AKISize_A2 / totalSize_A2), "00.0%")
        A2_KIDOU = 0

A3:
        If CheckBox3.Checked = False Then
            GoTo A4
        End If

        A3_KIDOU = 1
        On Error GoTo A4
        'ネットワーク経由
        'A3　X線空き容量
        Dim FSO3, A3
        FSO3 = CreateObject("Scripting.FileSystemObject")
        A3 = FSO3.GetFolder(TextBox17.Text)
        Dim totalSize_A3 = A3.Drive.TotalSize
        Dim AKISize_A3 = A3.Drive.FreeSpace
        TextBox18.Text = Format((totalSize_A3 / (1024 * 1024 * 1024)), ".0GB")
        TextBox19.Text = Format((AKISize_A3 / (1024 * 1024 * 1024)), ".0GB")
        TextBox20.Text = Format((AKISize_A3 / totalSize_A3), "00.0%")
        A3_KIDOU = 0

A4:
        If CheckBox4.Checked = False Then
            GoTo OWARI
        End If

        A4_KIDOU = 1
        On Error GoTo OWARI
        'ネットワーク経由
        'A4　X線空き容量
        Dim FSO4, A4
        FSO4 = CreateObject("Scripting.FileSystemObject")
        A4 = FSO4.GetFolder(TextBox13.Text)
        Dim totalSize_A4 = A4.Drive.TotalSize
        Dim AKISize_A4 = A4.Drive.FreeSpace
        TextBox14.Text = Format((totalSize_A4 / (1024 * 1024 * 1024)), ".0GB")
        TextBox15.Text = Format((AKISize_A4 / (1024 * 1024 * 1024)), ".0GB")
        TextBox16.Text = Format((AKISize_A4 / totalSize_A4), "00.0%")
        A4_KIDOU = 0

OWARI:
        '日にち時刻の取得
        NITIJI = Format(Year(Now), "0000") & "/" & Format(Month(Now), "00") & "/" & Format((Now.Day), "00")
        JIKAN = TimeString

        'テキストファイルへ履歴作成
        Dim FILENAME As String
        Dim WS As IO.StreamWriter

        'ディレクトリ判定
        If TextBox12.Text = "" Then
            FILENAME = System.IO.Path.Combine(Application.StartupPath(), "PC_HDD空き容量ログ.CSV")
            WS = New IO.StreamWriter(FILENAME, True, System.Text.Encoding.Default)
            WS.WriteLine(NITIJI & "," & JIKAN & "," & TextBox21.Text & "," & TextBox5.Text & "," & TextBox6.Text & "," & TextBox22.Text & "," & TextBox8.Text & "," & TextBox9.Text & "," & TextBox23.Text & "," & TextBox19.Text & "," & TextBox20.Text & "," & TextBox24.Text & "," & TextBox15.Text & "," & TextBox16.Text)
            WS.Close()
        Else
            WS = New IO.StreamWriter(TextBox12.Text & "PC_HDD空き容量ログ.CSV", True, System.Text.Encoding.Default)
            WS.WriteLine(NITIJI & "," & JIKAN & "," & TextBox21.Text & "," & TextBox5.Text & "," & TextBox6.Text & "," & TextBox22.Text & "," & TextBox8.Text & "," & TextBox9.Text & "," & TextBox23.Text & "," & TextBox19.Text & "," & TextBox20.Text & "," & TextBox24.Text & "," & TextBox15.Text & "," & TextBox16.Text)
            WS.Close()
        End If

        '空き容量注意　20%以下でメッセージ
        Dim A1_AKI As Decimal
        Dim A2_AKI As Decimal
        Dim A3_AKI As Decimal
        Dim A4_AKI As Decimal

        If CheckBox1.Checked = True And A1_KIDOU = 0 Then

            A1_AKI = Val(AKISize_A1 / totalSize_A1)
            If A1_AKI < Label14.Text Then
                MsgBox(TextBox10.Text & "の空き容量が少なくなっています。古いデータを移動して下さい。")
            End If
        End If

        If CheckBox2.Checked = True And A2_KIDOU = 0 Then
            A2_AKI = Val(AKISize_A2 / totalSize_A2)
            If A2_AKI < Label14.Text Then
                MsgBox(TextBox11.Text & "の空き容量が少なくなっています。古いデータを移動して下さい。")
            End If
        End If

        If CheckBox3.Checked = True And A3_KIDOU = 0 Then
            A3_AKI = Val(AKISize_A3 / totalSize_A3)
            If A3_AKI < Label14.Text Then
                MsgBox(TextBox17.Text & "の空き容量が少なくなっています。古いデータを移動して下さい。")
            End If
        End If

        If CheckBox4.Checked = True And A4_KIDOU = 0 Then
            A4_AKI = Val(AKISize_A4 / totalSize_A4)
            If A4_AKI < Label14.Text Then
                MsgBox(TextBox13.Text & "の空き容量が少なくなっています。古いデータを移動して下さい。")
            End If
        End If

        'X線PCオンライン確認、フォルダパス確認
        If A1_KIDOU = 1 Then
            MsgBox(TextBox10.Text & "はPC起動していないか、フォルダパスが変更されています。" & vbCrLf & "→新しいフォルダパスを入力して下さい。", , "HDD容量取得エラー")
        End If

        If A2_KIDOU = 1 Then
            MsgBox(TextBox11.Text & "はPC起動していないか、フォルダパスが変更されています。" & vbCrLf & "→新しいフォルダパスを入力して下さい。", , "HDD容量取得エラー")
        End If

        If A3_KIDOU = 1 Then
            MsgBox(TextBox17.Text & "はPC起動していないか、フォルダパスが変更されています。" & vbCrLf & "→新しいフォルダパスを入力して下さい。", , "HDD容量取得エラー")
        End If

        If A4_KIDOU = 1 Then
            MsgBox(TextBox13.Text & "はPC起動していないか、フォルダパスが変更されています。" & vbCrLf & "→新しいフォルダパスを入力して下さい。", , "HDD容量取得エラー")
        End If

        '「閉じる」ボタンへフォーカス移動
        Button3.Focus()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox1.ResetText()
        TextBox2.ResetText()
        TextBox3.ResetText()
        TextBox4.ResetText()
        TextBox5.ResetText()
        TextBox6.ResetText()
        TextBox7.ResetText()
        TextBox8.ResetText()
        TextBox9.ResetText()
        TextBox14.ResetText()
        TextBox15.ResetText()
        TextBox16.ResetText()
        TextBox18.ResetText()
        TextBox19.ResetText()
        TextBox20.ResetText()
        Button1.Focus()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.Close()
    End Sub
    '空き割合設定スクロールバー
    Private Sub TrackBar1_Scroll(sender As System.Object, e As System.EventArgs) Handles TrackBar1.Scroll
        Label12.Text = TrackBar1.Value
        Label14.Text = TrackBar1.Value * 0.01
    End Sub

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Label12.Text = Label14.Text * 100
    End Sub
End Class